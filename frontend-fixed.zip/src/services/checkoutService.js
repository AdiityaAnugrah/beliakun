const API_URL = `${import.meta.env.VITE_URL_BACKEND}`;

export const checkoutManual = async (payload, token) => {
  try {
    const res = await fetch(`${API_URL}/api/payment/tripay/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    return {
      status: res.status,
      data,
    };
  } catch (error) {
    console.error("Checkout failed", error);
    return {
      status: 500,
      message: "Server error",
    };
  }
};