import React from "react";

const FooterAdmin = () => {
    return (
        <footer className="admin-footer">
            <p>&copy; 2023 Admin Dashboard. All rights reserved.</p>
        </footer>
    );
};

export default FooterAdmin;
