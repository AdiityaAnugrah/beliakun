// controllers/paymentController.js
// Midtrans telah dihapus - digantikan oleh Tripay

module.exports = {};